# Chat
I decided to create a completly new chatapp with dart and create a client with dart too
I wanted to do this because I wanted to test the waters with this rather new programming language.
Sadly I was not able to find out how to relocate a dart project so you will have to be happy with the "quickstart" subdirectory.

To execute the app navigate to said quickstart directory and follow the readme.md file there

©ScarCheek