# Chatapp for Web
To execute this app you have to execute following commands: 
 - dart bin/server.dart
 - webdev serve --live-reload
#
Of course you need to have Dart installed.

To install follow this short and sweet guide: https://dart.dev/tutorials/web/get-started

©ScarCheek