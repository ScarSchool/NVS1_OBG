# Who did you cooperate with?
I worked closely together with Mr Tschlatscher as we finished this assignment together yesterday.\
We both got the FFT filtereing from this website: https://rosettacode.org/wiki/Fast_Fourier_transform#JavaScript